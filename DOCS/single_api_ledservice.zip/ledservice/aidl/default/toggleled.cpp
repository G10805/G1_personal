#include <iostream>
#include <fstream>
#include <string>
#include <unistd.h>
#include <log/log.h>

#include "toggleled.h"

using namespace std;

using namespace std;

namespace aidl {
namespace vendor {
namespace visteon {
namespace led {

std::shared_ptr<toggleled> toggleled::sInstance = nullptr;

const string GREEN_GPIO_PATH = "/sys/class/gpio/gpio331"; // Green LED
const string RED_GPIO_PATH = "/sys/class/gpio/gpio366"; // Red LED


std::shared_ptr<toggleled> toggleled::getInstance(){
    if(sInstance == nullptr){
        sInstance = ndk::SharedRefBase::make<toggleled>();
    }
    return sInstance;
}

toggleled::toggleled(){
  ALOGD("LED Service instantiated");  
  
}

toggleled::~toggleled(){

  ALOGD("Led service is being destroyed");

}

ndk::ScopedAStatus toggleled::turn_led_on_off(int led_num, int state) {
  if (led_num == GREEN_LED && state == OFF){
  ALOGV("Green Led is turning OFF");
      ofstream valueFile(GREEN_GPIO_PATH + "0");
    if (valueFile.is_open()) {
        valueFile << 0;
        valueFile.close();
        ALOGV("Green Led is turned OFF");
    }else{
      ALOGE("Unable to set GPIO 331 ON");
    }
  }
  if (led_num == GREEN_LED && state == ON){
   ALOGV("Green Led is turning ON....");
      ofstream valueFile(GREEN_GPIO_PATH + "1");
    if (valueFile.is_open()) {
        valueFile << 1;
        valueFile.close();
        ALOGV("Green Led is turned ON ");
    }else{
      ALOGE("Unable to set GPIO 331 OFF");
    }
  }
  if (led_num == RED_LED && state == OFF){
   ALOGV("Red Led is turning OFF");
      ofstream valueFile(RED_GPIO_PATH + "0");
    if (valueFile.is_open()) {
        valueFile << 0;
        valueFile.close();
        ALOGV("Red Led is turned OFF");
    }else{
      ALOGE("Unable to set GPIO 336 OFF");
    }
  }
  if (led_num == RED_LED && state == ON){
   ALOGV("Red Led is turning ON  ");
      ofstream valueFile(RED_GPIO_PATH + "1");
    if (valueFile.is_open()) {
        valueFile << 1;
        valueFile.close();
        ALOGV("Red Led is turned ON  ");
    }else{
      ALOGE("Unable to set GPIO 336 ON");
    }
  }
  return ndk::ScopedAStatus::ok();
}
    }  // namespace led
  }  // namespace visteon
 }  // namespace vendor
}  // namespace aidl