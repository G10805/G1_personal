#include <aidl/vendor/visteon/led/ILedService.h>
#include <android/binder_manager.h>
#include <android/binder_process.h>
#include <iostream>
#include <log/log.h>

using namespace aidl::vendor::visteon::led;

int main(int argc, char* argv[]) {

    if (argc < 1) {
        std::cerr << "Usage:\n"
                  << "  led_client red led on\n"
                  << "  led_client red led off\n"
                  << "  led_client green led on\n"
                  << "  led_client green led on\n";
        return 1;
    }

    ABinderProcess_setThreadPoolMaxThreadCount(1);
    ABinderProcess_startThreadPool();

    // Get the service
    ndk::SpAIBinder binder(AServiceManager_getService("vendor.visteon.led.ILedService/default"));
    if (!binder.get()) {
        ALOGE("Failed to get LED service");
        return 1;
    }else{
      ALOGV("LED Client instatiated....");
    }

    std::shared_ptr<ILedService> ledService = ILedService::fromBinder(binder);
    if (!ledService) {
        ALOGE("Failed to create LED service interface");
        return 1;
    }
    
    std::string led = argv[1];
    std::string state = argv[2];
    // Test APIs
    try{ 
        int l = std::stoi(argv[1]);
        int s = std::stoi(argv[2]);
          ledService->turn_led_on_off(l, s);
 
    }catch (const std::exception& e) {
        ALOGE("Error parsing arguments: %s", e.what());
        return 1;
    }

    return 0;
}
