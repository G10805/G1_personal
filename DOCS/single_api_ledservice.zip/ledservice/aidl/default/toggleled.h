#include <aidl/vendor/visteon/led/BnLedService.h>

namespace aidl::vendor::visteon::led {

class toggleled : public BnLedService {
public:
    toggleled();
    ~toggleled();
// Enum for LED identifiers
enum LED {
    GREEN_LED = 0,
    RED_LED = 1,
};

// Enum for LED states
enum LEDState {
    OFF = 0,
    ON = 1,
};

  ndk::ScopedAStatus turn_led_on_off(int led_num, int state) override;
  static std::shared_ptr<toggleled> sInstance;
  static std::shared_ptr<toggleled> getInstance();
  const std::string GREEN_GPIO_PATH = "/sys/class/gpio/gpio331"; // Green LED
  const std::string RED_GPIO_PATH = "/sys/class/gpio/gpio366"; // Red LED

};

} // namespace aidl::android::hardware::led